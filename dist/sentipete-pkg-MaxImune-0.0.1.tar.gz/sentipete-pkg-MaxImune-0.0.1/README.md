# SentiPete Package

## Description
    * This package provides a easy sentiment-analysis-pipeline using spacy
    * Only for german texts
    * You can analyse your text for user-given keywords to get associated polarity-values
    * Uses SpaCy's tokenizer/POS-tagger and dependency-parser to get keyword associated words
    * Works with experimental polarity-enhancer, polarity-reducer, polarity-switcher (due to negations)
    * Example: Das Wetter  ist sehr     schön    . Zum Glück bin ich         nicht    blind. 
    *              keyword     enhancer sentiment                keyword     negation sentiment
    *              0.01215 <\- 1.5   x  0.0081                   0.1978  <\-\-1   x   \-0.1978

## Dependencies
    * spacy\-nightly
    * german\-model: de\_core\_news\_md
    * re
    * os
    * pickle

## Use

