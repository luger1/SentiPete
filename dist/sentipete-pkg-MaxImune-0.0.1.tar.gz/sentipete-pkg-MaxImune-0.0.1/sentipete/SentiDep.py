import spacy
import re
import os
import pickle


class SentiDep:

    def __init__(self):
        self.sentiws = pickle.load(open(os.path.abspath("sentiws.pickle"), 'rb'))
        self.polarity_modifications = pickle.load(open(os.path.abspath("polarity_modifiers.pickle"), 'rb'))
        self.negations = pickle.load(open(os.path.abspath("negationen_lexicon.pickle"), 'rb'))
        self.nlp = spacy.load("de_core_news_md")

    def sentiws_spacy_tag_mapper(self, pos_tag, **kwargs):
        """Function for mapping SentiWS POS-tags to spacy POS-tags and reverse"""
        direction = kwargs.get('direction', 1)
        senti_map = {"ADJX": "ADJ", "ADV": "ADV", "NN": "NOUN", "VVINF": "VERB"}
        if direction > 0:
            return senti_map[pos_tag]
        elif direction < 0:
            return {value: key for key, value in senti_map.items()}[pos_tag]

    def get_polarity(self, word, pos_tag, sentiws):
        """Getter Function for retaining the polarity value by SentiWS for a certain word with POS-tag"""
        senti_words = list(filter(
            lambda x: x[0] == word and self.sentiws_spacy_tag_mapper(x[2]) == pos_tag, sentiws)
        )
        if senti_words:
            senti_words = sorted(senti_words, key=lambda y: y[1] ** 2, reverse=True)[0]
            return senti_words

    def modify_polarity(self, word, child, pos_tag, sentiws, polarity_modifications):
        """Function to consider polarity enhancer and reducer"""
        senti_word = self.get_polarity(word, pos_tag, sentiws)
        # print(senti_word)
        if child in polarity_modifications["polarity_enhancer"]:
            return (senti_word[0], senti_word[1] * 1.5, senti_word[2])
        elif child in polarity_modifications["polarity_reducer"]:
            return (senti_word[0], senti_word[1] * 0.5, senti_word[2])
        else:
            return senti_word

    def easy_switch(self, word, negations):
        """Function for finding depending negations in without dealing with complex issues"""
        neg_search = [re.search(r'%s' % (n), word) for n in negations["negation_regex"]]
        neg_search = list(filter(lambda z: z != None, neg_search))
        return bool(neg_search)

    def switch_polarity(self, word, child, pos_tag, sentiws, negations):
        # function for polarity switch with > 1 negations
        pass

    def get_depending_polarities(self, text, keywords):
        """Getter function for getting word-associated polarity values"""
        test_doc = self.nlp(text)
        associated_polarities = {}
        for token in test_doc:
            if token.text not in associated_polarities.keys():
                associated_polarities[token.text] = []
            if token.lower_ in keywords:
                es_trigger = False
                for child in token.children:
                    if self.easy_switch(child.lower_, self.negations):
                        negation = child.text
                        es_trigger = True
                for child in token.children:
                    if list(child.children):
                        for c in child.children:
                            mod_pol = self.modify_polarity(child.text, c.text,
                                                           child.pos_, self.sentiws,
                                                           self.polarity_modifications)
                            if mod_pol:
                                if es_trigger:
                                    mod_pol = (mod_pol[0], -mod_pol[1],
                                               mod_pol[2], "Negation: " + negation)
                                associated_polarities[token.text].append(mod_pol)
                    else:
                        child_pol = self.get_polarity(child.text, child.pos_, self.sentiws)
                        if child_pol:
                            if es_trigger:
                                child_pol = (child_pol[0], -child_pol[1],
                                             child_pol[2], "Negation: " + negation)
                            associated_polarities[token.text].append(child_pol)
        return {key: value for key, value in list(filter(lambda w: w[1], associated_polarities.items()))}


if __name__ == '__main__':
    import pandas as pd

    single_ratings = pd.read_excel("../Klinikbewertungen/Klinikbewertung_Einzelbewertungen.xlsx")
    single_reports = single_ratings["Erfahrungsbericht"].values.tolist()
    sd = SentiDep()
    for sr in single_reports[:10]:
        print(sd.get_depending_polarities(text=sr,
                                          keywords=["essen", "gefühl", "mitarbeiter", "arzt", "zimmer"]))
