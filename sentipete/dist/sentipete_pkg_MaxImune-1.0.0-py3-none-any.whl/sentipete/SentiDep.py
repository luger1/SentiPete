import spacy
import re
import os
import pickle
from germalemma import GermaLemma
from nltk import FreqDist
from nltk.corpus import stopwords


class SentiDep:

    def __init__(self, **kwargs):
        """
            Sentiment-Analyzer for german texts.
            Get the polarity values of words depending on
            polarity values of associated descriptive words
            e.g. 'das schöne Wetter' -> polarity of 'Wetter' == polarity of 'schöne'

            Purpose: find out in which sentiment context your keywords appear in a text.
            Note: Works with spacy, nltk and germalemma
        """
        sentiws_path = kwargs.get('sentiws_file', os.path.abspath("sentiws.pickle"))
        polarity_mod_path = kwargs.get('polarity_modifiers_file',
                                       os.path.abspath("polarity_modifiers.pickle"))
        negations_path = kwargs.get('negations_file', os.path.abspath("negationen_lexicon.pickle"))
        stts_path = kwargs.get('stts_file', os.path.abspath("stts.pickle"))
        self.sentiws = pickle.load(open(sentiws_path, 'rb'))
        self.polarity_modifications = pickle.load(open(polarity_mod_path, 'rb'))
        self.negations = pickle.load(open(negations_path, 'rb'))
        self.nlp = spacy.load("de_core_news_md")
        self.germalemmatizer = GermaLemma()
        self.stts = pickle.load(open(stts_path, 'rb'))
        self.german_stops = stopwords.words('german')

    def tokenize(self, text):
        """
        Tokenize a string using spacy's tokenizer.
        Input: text/string
        Output: spacy_doc
        """
        return self.nlp(text)

    def sentiws_spacy_tag_mapper(self, pos_tag, **kwargs):
        """
        Function for mapping SentiWS POS-tags to spacy POS-tags and reverse.
        Input: pos_tag, optional: direction
               -> values: 1 (sentiws to spacy), -1 (spacy to sentiws)
               -> default: 1
        Output: python str
        """
        direction = kwargs.get('direction', 1)
        senti_map = {"ADJX": "ADJ", "ADV": "ADV", "NN": "NOUN", "VVINF": "VERB"}
        if direction > 0:
            return senti_map[pos_tag]
        elif direction < 0:
            return {value: key for key, value in senti_map.items()}[pos_tag]

    def get_polarity(self, word, pos_tag):
        """
        Getter Function for retaining the polarity value by SentiWS for a certain word with POS-tag.
        Input: word, pos_tag
        Output: tuple(word, polarity-value, pos_tag)
        """
        senti_words = list(filter(
            lambda x: x[0] == word and self.sentiws_spacy_tag_mapper(x[2]) == pos_tag, self.sentiws)
        )
        if senti_words:
            senti_words = sorted(senti_words, key=lambda y: y[1] ** 2, reverse=True)[0]
            return senti_words

    def modify_polarity(self, child, polarity):
        """
        Function to consider polarity enhancer and reducer.
        Input: token.text, token.child.text, token.pos_ (of word)
        Output: tuple(word, polarity-value, pos_tag)
        """
        senti_word = polarity
        if senti_word:
            if child in self.polarity_modifications["polarity_enhancer"]:
                return (senti_word[0], senti_word[1] * 1.5, senti_word[2])
            elif child in self.polarity_modifications["polarity_reducer"]:
                return (senti_word[0], senti_word[1] * 0.5, senti_word[2])

    def easy_switch(self, word):
        """
        Function for finding depending negations without dealing with complex issues.
        Input: token/word
        Output: True/False
        """
        neg_search = [re.search(r'%s' % (n), word) for n in self.negations["negation_regex"]]
        neg_search = list(filter(lambda z: z != None, neg_search))
        return bool(neg_search)

    def add_polarities(self, list_of_polarity_tuples):
        """
        Summing up a list of polarity-tuples
        :param list_of_polarity_tuples:
        :return: polarity value -> float
        """
        all_pols = [lpt[1] for lpt in list_of_polarity_tuples]
        return sum(all_pols)

    def calc_parent_polarity(self, spacy_token, token_polarity, children_polarities):
        """
        Calculating the parent polarity value depending on the children polarities
        :param spacy_token:
        :param token_polarity:
        :param children_polarities:
        :return: parent_polarity -> tuple(word, polarity, POS-tag)
        """
        if token_polarity and children_polarities:
            added_children_polarities = self.add_polarities(children_polarities)
            if added_children_polarities > 0:
                token_polarity = (spacy_token.text,
                                  token_polarity[1] + added_children_polarities,
                                  spacy_token.pos_)
            elif added_children_polarities < 0:
                token_polarity = (spacy_token.text,
                                  (token_polarity[1] + (-1 * added_children_polarities)) * (-1),
                                  spacy_token.pos_)
        elif not token_polarity and children_polarities:
            token_polarity = (spacy_token.text,
                              self.add_polarities(children_polarities),
                              spacy_token.pos_)
        return token_polarity

    def switch_polarity(self, polarity, spacy_doc_sent):
        """
        Switching polarity value depending on negation context of whole sentence.
        Classic negation (kein, nicht, ...) are recognized as well as
        negation stops (aber, obwohl, ...)
        :param polarity:
        :param spacy_doc_sent:
        :return: tuple(word, polarity, POS-tag, negation: boolean)
        """
        negation_trigger = False
        for i, token in enumerate(spacy_doc_sent):
            for negex in self.negations['negation_regex']:
                regex = r'%s' % (negex)
                negation_search = re.search(regex, token.text, re.I)
                if negation_search:
                    negation_trigger = not negation_trigger
            if token.lower_ in self.negations['polarity_switches']:
                if token.text == '.':
                    if token.pos_ == 'PUNCT':
                        negation_trigger = not negation_trigger
                    else:
                        continue
                else:
                    negation_trigger = not negation_trigger
            if token.text == polarity[0]:
                if negation_trigger:
                    negated_polarity = (polarity[0], -polarity[1],
                                        polarity[2], "negation: " + str(negation_trigger))
                else:
                    negated_polarity = (polarity[0], polarity[1],
                                        polarity[2], "negation: " + str(negation_trigger))
                return negated_polarity

    def get_depending_polarities(self, text, keywords):
        """
        Get keyword associated polarity values of german texts.
        Polarity analysis including polarity reducer/enhancer and negations
        :param text:
        :param keywords:
        :return: Context-polarity value of keywords -> list of tuples
        """
        spacy_doc = self.nlp(text)
        parent_polarities = []
        keywords = [k.lower() for k in keywords]
        for sent in spacy_doc.sents:
            for i, token in enumerate(sent):
                token_polarity = self.get_polarity(token.text, token.pos_)
                children_polarities = []
                if token.lower_ in keywords:
                    children = token.children
                    if children:
                        for child in children:
                            child_polarity = self.get_polarity(child.text, child.pos_)
                            if child_polarity:
                                children_polarities.append(child_polarity)
                    parent_polarity = self.calc_parent_polarity(token, token_polarity, children_polarities)
                    if parent_polarity:
                        modified_parent_polarities = []
                        for child in children:
                            modified_parent_polarities.append(self.modify_polarity(child, parent_polarity))
                        added_modified_parent_polarity = None
                        if modified_parent_polarities:
                            added_modified_parent_polarity = self.add_polarities(modified_parent_polarities)
                        if added_modified_parent_polarity:
                            added_modified_parent_polarity = (token.text,
                                                              added_modified_parent_polarity,
                                                              token.pos_ + "_modified")
                            parent_polarities.append(self.switch_polarity(
                                added_modified_parent_polarity, sent))
                        else:
                            parent_polarities.append(self.switch_polarity(parent_polarity, sent))
        return parent_polarities

    def lemmatize(self, spacy_token):
        """
        Lemmatizer using stts-tagset, spacy-token and GermaLemma.
        Input: spacy token -> german model
        Output: python str
        """
        tag = spacy_token.tag_
        if tag.startswith(('N', 'V', 'ADJ', 'ADV')) and tag in self.stts:
            return self.germalemmatizer.find_lemma(spacy_token.text, tag)
        else:
            return spacy_token.text

    def generate_topics(self, text):
        """
        Generate a list with 30 most frequent nouns in a text.
        Input: text -> len(text) <= 50000
        Output: nltk.FreqDist-object
        """
        if len(text) > 50000:
            raise ValueError('text-length too long: input-text has to have char-length <= 50000')
        tokens = [token for token in sd.tokenize(text)]
        tokens = [self.lemmatize(t) for t in tokens if t.pos_ == 'NOUN' \
                  and t.lower_ not in self.german_stops]
        filtered_freq_dist = FreqDist(tokens)
        return filtered_freq_dist


if __name__ == '__main__':
    import pandas as pd

    single_ratings = pd.read_excel("../Klinikbewertungen/Klinikbewertung_Einzelbewertungen.xlsx")
    single_reports = single_ratings["Erfahrungsbericht"].values.tolist()
    sd = SentiDep(sentiws_file="../sentiws.pickle", polarity_modifiers_file="../polarity_modifiers.pickle",
                  negations_file="../negationen_lexicon.pickle", stts_file="../stts.pickle")
    topics = sd.generate_topics("".join(single_reports[:50]))
    topics.plot(30)
    first_30 = sorted(topics.items(), key=lambda x: x[1], reverse=True)[:30]
    first_30 = [fs[0] for fs in first_30]
    print(first_30)
    for sr in single_reports[:10]:
        print(sd.get_depending_polarities(text=sr, keywords=first_30))
                                    # keywords=["essen", "gefühl", "mitarbeiter", "arzt", "zimmer"])
